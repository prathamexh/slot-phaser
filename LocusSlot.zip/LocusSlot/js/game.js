
//my functions
function sleep(ms = 3000) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  


// create a scene
let gameScene = new Phaser.Scene("Game");
// load assets
gameScene.preload = function(){

    this.load.image('background','assets/slotbg.jpg');
    this.load.image('logo','assets/logo.png');
    this.load.image('spin','assets/spin.png');
    this.load.image('seven','assets/symbols/7.png');
    this.load.image('banana','assets/symbols/banana.png');
    this.load.image('bar','assets/symbols/bar.png');
    this.load.image('berrys','assets/symbols/berrys.png');
    this.load.image('melons','assets/symbols/melons.png');
    this.load.image('orange','assets/symbols/orange.png');
    this.load.image('blur1','assets/symbols/blurbanana.png');
    this.load.image('blur2','assets/symbols/blurcherry.png');
    this.load.image('blur3','assets/symbols/blurmelons.png');
    this.load.image('blur4','assets/symbols/blurseven.png');
    

};
let arr1 = ['banana','seven','bar','melons','orange','berrys','melons','orange','berrys']
let arr2 = ['banana','seven','bar','bar','orange','berrys','bar','bar','orange']
let arr3 = ['banana','seven','bar','melons','bar','banana','banana','seven','bar']
function rng(){ 
    return Math.floor(Math.random() * 9);
}
var l1 = 0;
var l2 = 2;
var l3 = 3;
var balance = 1000;
gameScene.create = function(){
    this.bg = this.add.sprite(600,350,'background');
    this.logo = this.add.sprite(600,180,'logo');
    this.logo.setScale(0.8);
    this.play = this.add.sprite(600,580,'spin').setInteractive();
    balanceText = this.add.text(16, 16, 'Balance:', { fontSize: '32px', fill: '#FFF' });
    balanceText.setText('Balance: ' + balance);
    loc1 = this.add.sprite(410,370,'bar');
    loc2 = this.add.sprite(600,370,'melons');
    loc3 = this.add.sprite(790,370,'banana');
    loc1.setTexture(arr1[l1])
    loc2.setTexture(arr1[l2])
    loc3.setTexture(arr1[l3])
    // console.log(loc1)
    
};

// var health = 100;
var timeSinceLastIncrement = 0;
var timesli = 0
gameScene.update = function(){
    // console.log(loc1)
    timeSinceLastIncrement += 0.5;
    this.play.on('pointerdown',async function (pointer){
        if (timeSinceLastIncrement >= 10)  
        {

                   timeSinceLastIncrement = 0;
  
                   l1 = rng()
                   l2 = rng()
                   l3 = rng()
                   console.log("nahi ho mere")
                   loc1.setTexture('blur1')
                   await sleep(80)
                   loc1.setTexture('blur2')
                   await sleep(80)
                   loc1.setTexture('blur3')
                   await sleep(80)
                   loc1.setTexture('blur4')
                   await sleep(80)
                   loc1.setTexture(arr1[l1])
                   await sleep(80)
                   loc2.setTexture('blur1')
                   await sleep(80)
                   loc2.setTexture('blur2')
                   await sleep(80)
                   loc2.setTexture('blur3')
                   await sleep(80)
                   loc2.setTexture('blur4')
                   await sleep(80)
                   loc2.setTexture(arr2[l2])
                   await sleep(80)
                   loc3.setTexture('blur1')
                   await sleep(80)
                   loc3.setTexture('blur2')
                   await sleep(80)
                   loc3.setTexture('blur3')
                   await sleep(80)
                   loc3.setTexture('blur4')
                   await sleep(80)
                   loc3.setTexture(arr3[l3])
                   if(arr1[l1] == arr2[l2] && arr2[l2] == arr3[l3]){
                       console.log(l1,l2,l3)
                       balance += 1000;
                   }else{
                       balance -= 10;
                   }
                   balanceText.setText('Balance: ' + balance);
                   console.log(balance)
        }
    });

};
// create config
let config = {
    type:Phaser.AUTO,
    width:1200,
    height:700,
    scene:gameScene
};
// create a game and pass config
let game = new Phaser.Game(config);